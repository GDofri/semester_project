This dataset is contains images with height of 32px and variable width.
They are stored as npy files, each containing a 2d array of dtype('uint16')
